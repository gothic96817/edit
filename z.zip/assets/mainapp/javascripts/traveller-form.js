$(document).ready(function(){
    let phoneNumberInputElem = document.getElementById('phoneNumber');
    if(phoneNumberInputElem) {
        phoneNumberInputElem.addEventListener('input', function (e) {
            var x = e.target.value.replace(/\D/g, '').match(/(\d{0,2})(\d{0,9})/);
            if(!x[2]) {
                e.target.value = x[1];
            } else {
                if(x[1]!='09') {
                    e.target.value = '09' + x[1] + x[2];
                } else {
                    e.target.value = '09' + x[2];
                }
            }
        });
    }
});