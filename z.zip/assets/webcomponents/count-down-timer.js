/*
<count-down-timer remaining-seconds="30" tick-interval-seconds="3"
                 text-color="#111" text-color-class="text-success"
                 template="{{m}} m : {{s}} s">
</count-down-timer>
*/

class CountDownTimerComponent extends HTMLElement{
    constructor(){
        super();

        let getOrDefault = (val, defaultVal) => (val != undefined)? val : defaultVal;

        let textClass = getOrDefault(this.getAttribute("text-class"), "");
        let textColor = getOrDefault(this.getAttribute("text-color"), "");
        let style = (textColor)? `color:${textColor}` : "";

        this.innerHTML = `<span id="countdown-timer" class="${textClass}" style="${style}"></span>`;
    }

    connectedCallback() {
        let remainingSeconds = this.getAttribute("remaining-seconds");
        //console.log("init remaining seconds", remainingSeconds);

        let tickIntervalSeconds = this.getAttribute("tick-interval-seconds");

        let toMilliSeconds = (seconds) => seconds * 1000;

        let targetTime = Date.now() + toMilliSeconds(remainingSeconds);
        let tickIntervalInMilliSeconds = toMilliSeconds(tickIntervalSeconds);

        this.updateCountdownTimer(parseInt(remainingSeconds));

        let timer = setInterval(() => {
            let remainingSeconds = (targetTime - Date.now()) / toMilliSeconds(1);
            //console.log("remaining seconds", remainingSeconds);
            if (remainingSeconds < 0) {
                clearInterval(timer);
            }
            this.updateCountdownTimer(parseInt(remainingSeconds));
        }, tickIntervalInMilliSeconds);
    }

    updateCountdownTimer(remainingSeconds) {
        let minutes = (remainingSeconds>0)? Math.floor(remainingSeconds / 60) : 0;
        let seconds = (remainingSeconds>0)? Math.floor(remainingSeconds % 60) : 0;

        let displayElem = document.getElementById("countdown-timer");

        let formattedMinutes = this.formatDoubleDigit(minutes);
        let formattedSeconds = this.formatDoubleDigit(seconds) + ((this.secondLabel)? this.secondLabel : "");

        let template = this.getAttribute("template");
        if(template != null) {
            displayElem.innerHTML = template.replace("{{m}}", formattedMinutes).replace("{{s}}", formattedSeconds);
        } else {
            displayElem.innerHTML = formattedMinutes + " : " + formattedSeconds;
        }
    }

    formatDoubleDigit(val) {
        return (val < 10) ? ("0" + val) : val;
    }
}

customElements.define('count-down-timer', CountDownTimerComponent);

